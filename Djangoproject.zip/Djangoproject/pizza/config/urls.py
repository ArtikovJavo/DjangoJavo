from django.urls import path,include
from .views import index, burgers

urlpatterns = [
    path('', index, name="index"),
    path('burgers/', burgers, name="burgers")
]