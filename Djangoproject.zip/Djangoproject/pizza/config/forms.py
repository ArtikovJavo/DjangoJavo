from django import forms

class UseForm(forms.Form):
    age = forms.IntegerField(label="Количество", initial=0)
    two = forms.IntegerField(label="Количество", initial=0)
    three = forms.IntegerField(label="Количество", initial=0)
    four = forms.IntegerField(label="Количество", initial=0)
    five = forms.IntegerField(label="Количество", initial=0)
    six = forms.IntegerField(label="Количество", initial=0)
    # age = int()
    # t = 2 + age



    
        


    # l = int(six * 65000) + (four * 65000) + (five * 52000) + (three * 50000) + (two * 45000) + (age * 42000)
