from django.shortcuts import render
from .forms import UseForm

def index(request):
    forms = UseForm()
    return render(request, "index.html", {"forms":forms})



def burgers(request):
    return render(request, "config/burgers.html")
# Create your views here.
